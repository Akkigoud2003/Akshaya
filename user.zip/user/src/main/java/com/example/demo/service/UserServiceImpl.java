package com.example.demo.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;


@Repository
public class UserServiceImpl implements UserService {
	@Autowired
	UserRepository repository; {

}

	@Override
	public User saveUser(User user) {
		// TODO Auto-generated method stub
		return repository.save(user);
	}

	@Override
	public List<User> fetchUserList() {
		// TODO Auto-generated method stub
		return  repository.findAll();
	}

	@Override
	public User fetchUserById(Long id) {
		// TODO Auto-generated method stub
		return  repository.findById(id).get();
	}

	@Override
	public void deleteUserById(Long id) {
		// TODO Auto-generated method stub
		 repository.deleteById(id);
	}
	@Override
	public User updateUser(long userId, User user) {
		// TODO Auto-generated method stub
User user2= repository.findById(userId).get();
		
		if(Objects.nonNull(user.getPassword()) &&
			       !"".equals(user.getPassword())) {
			           user2.setPassword(user.getPassword());
			       }

			      
			       if(Objects.nonNull(user.getName()) &&!"".equalsIgnoreCase(user.getName())) {
			           user2.setName(user.getName());
			       }

			       return repository.save(user2);
	}

	
}

