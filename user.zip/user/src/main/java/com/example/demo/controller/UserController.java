package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.service.annotation.PutExchange;

import com.example.demo.entity.User;
import com.example.demo.service.UserService;

@RestController
public class UserController {
	
	@Autowired
	private UserService service;
	
	@PostMapping("/user")
	public User saveuser(@RequestBody User user) {
		return service.saveUser(user);
	}
	@GetMapping("/user")
	public List<User> fetchUserList(){
		return service.fetchUserList();
	
	}
	@GetMapping("/user/{id}") 
	public User fetchUserById(@PathVariable("id") Long id) {
		return service.fetchUserById(id);
		
	}
	@DeleteMapping("/user/{id}")
	public String deleteUserById(@PathVariable("id") Long id) {
		service.deleteUserById(id);
		return "User deleted successfully!!";
	}
	@PutMapping("/user/{id}") 
	 public User updateUser(@PathVariable("id") long userId, @RequestBody
	  User user) { 
		  return service.updateUser(userId,user);

	
}
}

	 
	 
	







